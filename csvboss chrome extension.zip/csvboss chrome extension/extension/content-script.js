(function () {

  // ─── TRANSLATIONS ────────────────────────────────────────────────────────────
  const STRINGS = {
    en: {
      title: 'Nickname Manager',
      toggleBtn: 'Nickname Manager',
      prefix: 'Prefix',
      prefixPlaceholder: 'e.g. [TAG] ',
      csvLabel: 'CSV — STEAMID64,NAME',
      csvPlaceholder: '76561198000000001,Player One\n76561198000000002,Player Two',
      langFilter: 'Language Filter',
      entries: 'Entries', applied: 'Applied', failed: 'Failed',
      applyBtn: 'Apply Nicknames', clearBtn: 'Clear',
      removeAllBtn: 'Remove All Nicknames',
      friendManager: 'Friend Manager',
      addFromCSV: 'Add from CSV', unfriendFromCSV: 'Unfriend from CSV',
      queued: 'Queued', done: 'Done',
      confirmRemoveAll: 'Remove ALL Steam nicknames? This cannot be undone.',
      confirmUnfriend: 'Unfriend all users in the CSV? This cannot be undone.',
      noValidEntries: 'No valid entries.',
      noValidEntriesCSV: 'No valid entries in CSV.',
      fetchingFriends: 'Fetching friends list...',
      noFriends: 'No friends found or not logged in.',
      applying: n => `Applying ${n} nicknames...`,
      finished: (ok, err) => `Finished. ${ok} applied, ${err} failed.`,
      foundUsers: n => `Found ${n} users. Clearing nicknames...`,
      doneCleared: (ok, err) => `Done. ${ok} cleared, ${err} failed.`,
      sendingReqs: n => `Sending friend requests to ${n} users...`,
      unfriending: n => `Unfriending ${n} users...`,
      doneOp: (ok, err) => `Done. ${ok} succeeded, ${err} failed.`,
      errorMsg: e => `Error: ${e}`,
    },
    ru: {
      title: 'Менеджер никнеймов',
      toggleBtn: 'Менеджер никнеймов',
      prefix: 'Префикс',
      prefixPlaceholder: 'напр. [КЛ] ',
      csvLabel: 'CSV — STEAMID64,ИМЯ',
      csvPlaceholder: '76561198000000001,Игрок Один\n76561198000000002,Игрок Два',
      langFilter: 'Языковой фильтр',
      entries: 'Записей', applied: 'Применено', failed: 'Ошибок',
      applyBtn: 'Применить никнеймы', clearBtn: 'Очистить',
      removeAllBtn: 'Удалить все никнеймы',
      friendManager: 'Менеджер друзей',
      addFromCSV: 'Добавить из CSV', unfriendFromCSV: 'Удалить из друзей',
      queued: 'В очереди', done: 'Готово',
      confirmRemoveAll: 'Удалить ВСЕ Steam никнеймы? Это нельзя отменить.',
      confirmUnfriend: 'Удалить всех из CSV из друзей? Это нельзя отменить.',
      noValidEntries: 'Нет корректных записей.',
      noValidEntriesCSV: 'Нет корректных записей в CSV.',
      fetchingFriends: 'Загрузка списка друзей...',
      noFriends: 'Друзья не найдены или вы не вошли в аккаунт.',
      applying: n => `Применяем ${n} никнеймов...`,
      finished: (ok, err) => `Готово. Применено: ${ok}, ошибок: ${err}.`,
      foundUsers: n => `Найдено ${n} пользователей. Удаляем никнеймы...`,
      doneCleared: (ok, err) => `Готово. Очищено: ${ok}, ошибок: ${err}.`,
      sendingReqs: n => `Отправляем заявки ${n} пользователям...`,
      unfriending: n => `Удаляем из друзей ${n} пользователей...`,
      doneOp: (ok, err) => `Готово. Успешно: ${ok}, ошибок: ${err}.`,
      errorMsg: e => `Ошибка: ${e}`,
    },
    cn: {
      title: '昵称管理器',
      toggleBtn: '昵称管理器',
      prefix: '前缀',
      prefixPlaceholder: '例如 [标签] ',
      csvLabel: 'CSV — STEAMID64,昵称',
      csvPlaceholder: '76561198000000001,玩家一\n76561198000000002,玩家二',
      langFilter: '语言筛选',
      entries: '条目', applied: '已应用', failed: '失败',
      applyBtn: '应用昵称', clearBtn: '清除',
      removeAllBtn: '移除所有昵称',
      friendManager: '好友管理器',
      addFromCSV: '从CSV添加', unfriendFromCSV: '从CSV删除好友',
      queued: '队列', done: '完成',
      confirmRemoveAll: '移除所有Steam昵称？此操作无法撤销。',
      confirmUnfriend: '删除CSV中所有好友？此操作无法撤销。',
      noValidEntries: '没有有效条目。',
      noValidEntriesCSV: 'CSV中没有有效条目。',
      fetchingFriends: '正在获取好友列表...',
      noFriends: '未找到好友或未登录。',
      applying: n => `正在应用 ${n} 个昵称...`,
      finished: (ok, err) => `完成。已应用：${ok}，失败：${err}。`,
      foundUsers: n => `找到 ${n} 个用户。正在清除昵称...`,
      doneCleared: (ok, err) => `完成。已清除：${ok}，失败：${err}。`,
      sendingReqs: n => `正在向 ${n} 个用户发送好友请求...`,
      unfriending: n => `正在删除 ${n} 个好友...`,
      doneOp: (ok, err) => `完成。成功：${ok}，失败：${err}。`,
      errorMsg: e => `错误：${e}`,
    },
  };

  let lang = 'en';
  function t(key, ...args) {
    const val = STRINGS[lang]?.[key] ?? STRINGS.en[key];
    return typeof val === 'function' ? val(...args) : val;
  }

  // ─── STEAM API ────────────────────────────────────────────────────────────────
  function getSessionId() {
    try { return window.g_sessionID || document.cookie.match(/sessionid=([^;]+)/)?.[1] || null; }
    catch { return null; }
  }

  async function addFriend(steamId) {
    const sessionId = getSessionId();
    if (!sessionId) throw new Error('No session ID — are you logged in?');
    const res = await fetch('https://steamcommunity.com/actions/AddFriendAjax', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: `sessionID=${encodeURIComponent(sessionId)}&steamid=${encodeURIComponent(steamId)}&accept_invite=0`
    });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { throw new Error(`HTTP ${res.status}`); }
    if (data.failed_invites_result?.length) {
      const code = data.failed_invites_result[0];
      if (code === 8) throw new Error('already friends or request pending');
      if (code === 84) throw new Error('their profile restricts friend invites');
      throw new Error(`rejected by Steam (code ${code})`);
    }
    if (data.success !== 1) throw new Error(`failed (success=${data.success})`);
  }

  async function removeFriend(steamId) {
    const sessionId = getSessionId();
    if (!sessionId) throw new Error('No session ID — are you logged in?');
    const res = await fetch('https://steamcommunity.com/actions/RemoveFriendAjax', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: `sessionid=${encodeURIComponent(sessionId)}&steamid=${encodeURIComponent(steamId)}`
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${text.slice(0, 120)}`);
  }

  async function setNickname(steamId, nickname) {
    const sessionId = getSessionId();
    if (!sessionId) throw new Error('No session ID — are you logged in?');
    const url = `https://steamcommunity.com/profiles/${steamId}/ajaxsetnickname/`;
    async function attempt() {
      return fetch(url, {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
        body: `nickname=${encodeURIComponent(nickname)}&sessionid=${encodeURIComponent(sessionId)}`
      });
    }
    let res = await attempt().catch(() => null);
    if (!res || !res.ok) { await sleep(800); res = await attempt().catch(() => null); }
    if (!res || !res.ok) throw new Error('Request failed');
    return res.text();
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function parseCSV(text) {
    return text.trim().split('\n')
      .map(l => l.trim()).filter(Boolean)
      .map(line => {
        const parts = line.split(',');
        if (parts.length < 2) return null;
        const steamId = parts[0].trim();
        const nickname = parts[1].trim();
        const lang = parts[2] ? parts[2].trim().toLowerCase() : '';
        if (!/^\d{17}$/.test(steamId)) return null;
        return { steamId, nickname, lang };
      }).filter(Boolean);
  }

  function filterByLang(entries) {
    const checked = [...document.querySelectorAll('.csvboss-lang-cb:checked')].map(c => c.value);
    if (!checked.length || checked.includes('all')) return entries;
    return entries.filter(e => checked.includes(e.lang));
  }

  // ─── UI ───────────────────────────────────────────────────────────────────────
  function applyLang() {
    const set = (id, key) => { const el = document.getElementById(id); if (el) el.textContent = t(key); };
    const setPlaceholder = (id, key) => { const el = document.getElementById(id); if (el) el.placeholder = t(key); };
    const setAttr = (id, attr, key) => { const el = document.getElementById(id); if (el) el.setAttribute(attr, t(key)); };

    document.getElementById('csvboss-title-text').textContent = t('title');
    document.getElementById('csvboss-toggle').textContent = t('toggleBtn');
    document.getElementById('csvboss-prefix-label').textContent = t('prefix');
    setPlaceholder('csvboss-prefix', 'prefixPlaceholder');
    document.getElementById('csvboss-csv-label').textContent = t('csvLabel');
    setPlaceholder('csvboss-csv', 'csvPlaceholder');
    document.getElementById('csvboss-lang-label').textContent = t('langFilter');
    document.getElementById('lbl-entries').textContent = t('entries');
    document.getElementById('lbl-applied').textContent = t('applied');
    document.getElementById('lbl-failed').textContent = t('failed');
    document.getElementById('btn-apply').textContent = t('applyBtn');
    document.getElementById('btn-clear-input').textContent = t('clearBtn');
    document.getElementById('btn-unnick').textContent = t('removeAllBtn');
    document.getElementById('csvboss-friend-label').textContent = t('friendManager');
    document.getElementById('btn-add-friends-text').textContent = t('addFromCSV');
    document.getElementById('btn-unfriend-text').textContent = t('unfriendFromCSV');
    document.getElementById('lbl-queued').textContent = t('queued');
    document.getElementById('lbl-done').textContent = t('done');
    document.getElementById('lbl-f-failed').textContent = t('failed');

    // highlight active lang button
    document.querySelectorAll('.csvboss-lang-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.lang === lang);
    });
  }

  function buildUI() {
    if (document.getElementById('csvboss-panel')) return;

    const toggle = document.createElement('button');
    toggle.id = 'csvboss-toggle';
    toggle.textContent = t('toggleBtn');
    document.body.appendChild(toggle);

    const panel = document.createElement('div');
    panel.id = 'csvboss-panel';
    panel.innerHTML = `
      <div id="csvboss-header">
        <div id="csvboss-title">
          <span id="csvboss-title-text">Nickname Manager</span> <span class="csvboss-sub">csvboss</span>
        </div>
        <div id="csvboss-header-right">
          <div id="csvboss-lang-switcher">
            <button class="csvboss-lang-btn" data-lang="en">EN</button>
            <button class="csvboss-lang-btn" data-lang="ru">RU</button>
            <button class="csvboss-lang-btn" data-lang="cn">中文</button>
          </div>
          <button id="csvboss-close">&#x2715;</button>
        </div>
      </div>
      <div id="csvboss-body">
        <div class="csvboss-section">
          <div class="csvboss-label" id="csvboss-prefix-label">Prefix</div>
          <input id="csvboss-prefix" class="csvboss-input" type="text" placeholder="e.g. [TAG] ">
        </div>
        <div class="csvboss-section">
          <div class="csvboss-label" id="csvboss-csv-label">CSV — STEAMID64,NAME</div>
          <textarea id="csvboss-csv" class="csvboss-input" placeholder="76561198000000001,Player One&#10;76561198000000002,Player Two"></textarea>
        </div>
        <div class="csvboss-section">
          <div class="csvboss-label" id="csvboss-lang-label">Language Filter</div>
          <div class="csvboss-lang-row">
            <label class="csvboss-lang-chip"><input class="csvboss-lang-cb" type="checkbox" value="all" checked><span>All</span></label>
            <label class="csvboss-lang-chip"><input class="csvboss-lang-cb" type="checkbox" value="ru"><span>🇷🇺 Russian</span></label>
            <label class="csvboss-lang-chip"><input class="csvboss-lang-cb" type="checkbox" value="en"><span>🇬🇧 English</span></label>
            <label class="csvboss-lang-chip"><input class="csvboss-lang-cb" type="checkbox" value="cn"><span>🇨🇳 Chinese</span></label>
          </div>
        </div>
        <div class="csvboss-stats">
          <div class="csvboss-stat"><div class="num" id="stat-total">0</div><div class="lbl" id="lbl-entries">Entries</div></div>
          <div class="csvboss-stat"><div class="num" id="stat-ok">0</div><div class="lbl" id="lbl-applied">Applied</div></div>
          <div class="csvboss-stat"><div class="num" id="stat-err">0</div><div class="lbl" id="lbl-failed">Failed</div></div>
        </div>
        <div id="csvboss-progress"><div id="csvboss-progress-bar"></div></div>
        <div class="csvboss-row">
          <button class="csvboss-btn csvboss-btn-primary" id="btn-apply">Apply Nicknames</button>
          <button class="csvboss-btn csvboss-btn-secondary" id="btn-clear-input">Clear</button>
        </div>
        <div class="csvboss-divider"></div>
        <div class="csvboss-row">
          <button class="csvboss-btn csvboss-btn-danger" id="btn-unnick">Remove All Nicknames</button>
        </div>
        <div id="csvboss-log"></div>
        <div class="csvboss-divider"></div>
        <div class="csvboss-label" id="csvboss-friend-label">Friend Manager</div>
        <div class="csvboss-friend-actions">
          <button class="csvboss-action-item csvboss-action-add" id="btn-add-friends">
            <span class="csvboss-action-icon">&#10003;</span>
            <span id="btn-add-friends-text">Add from CSV</span>
          </button>
          <button class="csvboss-action-item csvboss-action-unfriend" id="btn-unfriend-csv">
            <span class="csvboss-action-icon">&#10005;</span>
            <span id="btn-unfriend-text">Unfriend from CSV</span>
          </button>
        </div>
        <div class="csvboss-stats" id="friend-stats" style="display:none">
          <div class="csvboss-stat"><div class="num" id="stat-f-total">0</div><div class="lbl" id="lbl-queued">Queued</div></div>
          <div class="csvboss-stat"><div class="num" id="stat-f-ok">0</div><div class="lbl" id="lbl-done">Done</div></div>
          <div class="csvboss-stat"><div class="num" id="stat-f-err">0</div><div class="lbl" id="lbl-f-failed">Failed</div></div>
        </div>
        <div id="csvboss-progress2"><div id="csvboss-progress-bar2"></div></div>
        <div id="csvboss-log2"></div>
      </div>
    `;
    document.body.appendChild(panel);

    // ── Lang switcher ──
    document.querySelectorAll('.csvboss-lang-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        lang = btn.dataset.lang;
        chrome.storage.local.set({ csvboss_lang: lang });
        applyLang();
      });
    });

    let running = false;
    const csvInput = document.getElementById('csvboss-csv');
    const prefixInput = document.getElementById('csvboss-prefix');
    const log = document.getElementById('csvboss-log');
    const progress = document.getElementById('csvboss-progress');
    const progressBar = document.getElementById('csvboss-progress-bar');

    chrome.storage.local.get(['csvboss_csv', 'csvboss_prefix', 'csvboss_lang'], (data) => {
      if (data.csvboss_csv) csvInput.value = data.csvboss_csv;
      if (data.csvboss_prefix) prefixInput.value = data.csvboss_prefix;
      if (data.csvboss_lang && STRINGS[data.csvboss_lang]) lang = data.csvboss_lang;
      applyLang();
      updateStats();
    });

    csvInput.addEventListener('input', () => { chrome.storage.local.set({ csvboss_csv: csvInput.value }); updateStats(); });
    prefixInput.addEventListener('input', () => chrome.storage.local.set({ csvboss_prefix: prefixInput.value }));

    function updateStats() {
      document.getElementById('stat-total').textContent = filterByLang(parseCSV(csvInput.value)).length;
    }

    document.querySelectorAll('.csvboss-lang-cb').forEach(cb => {
      cb.addEventListener('change', () => {
        if (cb.value === 'all' && cb.checked) {
          document.querySelectorAll('.csvboss-lang-cb:not([value="all"])').forEach(c => c.checked = false);
        } else if (cb.value !== 'all' && cb.checked) {
          document.querySelector('.csvboss-lang-cb[value="all"]').checked = false;
        }
        updateStats();
      });
    });

    function addLog(msg, type = 'info') {
      log.classList.add('visible');
      const line = document.createElement('div');
      line.className = `log-${type}`;
      line.textContent = msg;
      log.appendChild(line);
      log.scrollTop = log.scrollHeight;
    }
    function clearLog() { log.innerHTML = ''; log.classList.remove('visible'); }

    function lockBtns(lock) {
      document.querySelectorAll('.csvboss-btn, .csvboss-action-item').forEach(b => b.disabled = lock);
    }

    document.getElementById('btn-apply').addEventListener('click', async () => {
      if (running) return;
      clearLog();
      const entries = filterByLang(parseCSV(csvInput.value));
      if (!entries.length) { addLog(t('noValidEntries'), 'err'); return; }
      const prefix = prefixInput.value.trim();
      running = true; lockBtns(true);
      progress.classList.add('visible'); progressBar.style.width = '0%';
      document.getElementById('stat-ok').textContent = '0';
      document.getElementById('stat-err').textContent = '0';
      addLog(t('applying', entries.length));
      let ok = 0, err = 0;
      for (let i = 0; i < entries.length; i++) {
        const { steamId, nickname } = entries[i];
        const full = prefix ? `${prefix}${nickname}` : nickname;
        try {
          await setNickname(steamId, full);
          ok++;
          addLog(`+ ${steamId}  ${full}`, 'ok');
        } catch (e) {
          err++;
          addLog(`- ${steamId}  ${e.message}`, 'err');
        }
        document.getElementById('stat-ok').textContent = ok;
        document.getElementById('stat-err').textContent = err;
        progressBar.style.width = `${((i + 1) / entries.length) * 100}%`;
        await sleep(1500);
      }
      addLog(t('finished', ok, err));
      running = false; lockBtns(false);
    });

    document.getElementById('btn-unnick').addEventListener('click', async () => {
      if (running) return;
      if (!confirm(t('confirmRemoveAll'))) return;
      clearLog();
      running = true; lockBtns(true);
      progress.classList.add('visible'); progressBar.style.width = '0%';
      addLog(t('fetchingFriends'));
      try {
        const res = await fetch('https://steamcommunity.com/my/friends/', { credentials: 'include' });
        const html = await res.text();
        const matches = [...html.matchAll(/data-steamid="(\d{17})"/g)];
        const steamIds = [...new Set(matches.map(m => m[1]))];
        if (!steamIds.length) { addLog(t('noFriends'), 'err'); running = false; lockBtns(false); return; }
        addLog(t('foundUsers', steamIds.length));
        document.getElementById('stat-total').textContent = steamIds.length;
        document.getElementById('stat-ok').textContent = '0';
        document.getElementById('stat-err').textContent = '0';
        let ok = 0, err = 0;
        for (let i = 0; i < steamIds.length; i++) {
          try {
            await setNickname(steamIds[i], '');
            ok++;
            addLog(`+ cleared ${steamIds[i]}`, 'ok');
          } catch (e) {
            err++;
            addLog(`- ${steamIds[i]}  ${e.message}`, 'err');
          }
          document.getElementById('stat-ok').textContent = ok;
          document.getElementById('stat-err').textContent = err;
          progressBar.style.width = `${((i + 1) / steamIds.length) * 100}%`;
          await sleep(1500);
        }
        addLog(t('doneCleared', ok, err));
      } catch (e) { addLog(t('errorMsg', e.message), 'err'); }
      running = false; lockBtns(false);
    });

    const progress2 = document.getElementById('csvboss-progress2');
    const progressBar2 = document.getElementById('csvboss-progress-bar2');
    const log2 = document.getElementById('csvboss-log2');
    const friendStats = document.getElementById('friend-stats');

    function addLog2(msg, type = 'info') {
      log2.classList.add('visible');
      const line = document.createElement('div');
      line.className = `log-${type}`;
      line.textContent = msg;
      log2.appendChild(line);
      log2.scrollTop = log2.scrollHeight;
    }
    function clearLog2() { log2.innerHTML = ''; log2.classList.remove('visible'); }

    async function runFriendOp(label, op) {
      if (running) return;
      const entries = filterByLang(parseCSV(csvInput.value));
      if (!entries.length) { addLog2(t('noValidEntriesCSV'), 'err'); return; }
      running = true; lockBtns(true);
      clearLog2();
      friendStats.style.display = 'flex';
      progress2.classList.add('visible'); progressBar2.style.width = '0%';
      document.getElementById('stat-f-total').textContent = entries.length;
      document.getElementById('stat-f-ok').textContent = '0';
      document.getElementById('stat-f-err').textContent = '0';
      addLog2(`${label} ${entries.length}...`);
      let ok = 0, err = 0;
      for (let i = 0; i < entries.length; i++) {
        const { steamId } = entries[i];
        try {
          await op(steamId);
          ok++;
          addLog2(`+ ${steamId}`, 'ok');
        } catch (e) {
          err++;
          addLog2(`- ${steamId}  ${e.message}`, 'err');
        }
        document.getElementById('stat-f-ok').textContent = ok;
        document.getElementById('stat-f-err').textContent = err;
        progressBar2.style.width = `${((i + 1) / entries.length) * 100}%`;
        await sleep(1500);
      }
      addLog2(t('doneOp', ok, err));
      running = false; lockBtns(false);
    }

    document.getElementById('btn-add-friends').addEventListener('click', () => {
      runFriendOp(t('sendingReqs', ''), addFriend);
    });

    document.getElementById('btn-unfriend-csv').addEventListener('click', () => {
      if (!confirm(t('confirmUnfriend'))) return;
      runFriendOp(t('unfriending', ''), removeFriend);
    });

    document.getElementById('btn-clear-input').addEventListener('click', () => {
      csvInput.value = ''; chrome.storage.local.remove('csvboss_csv'); updateStats(); clearLog();
    });

    document.getElementById('csvboss-close').addEventListener('click', () => {
      panel.style.display = 'none'; toggle.style.display = 'block';
    });
    toggle.addEventListener('click', () => {
      panel.style.display = 'block'; toggle.style.display = 'none';
    });

    let dragging = false, dx = 0, dy = 0;
    document.getElementById('csvboss-header').addEventListener('mousedown', e => {
      dragging = true;
      dx = e.clientX - panel.getBoundingClientRect().left;
      dy = e.clientY - panel.getBoundingClientRect().top;
    });
    document.addEventListener('mousemove', e => {
      if (!dragging) return;
      panel.style.right = 'auto';
      panel.style.left = `${e.clientX - dx}px`;
      panel.style.top = `${e.clientY - dy}px`;
    });
    document.addEventListener('mouseup', () => dragging = false);
  }

  if (document.readyState === 'complete') buildUI();
  else window.addEventListener('load', buildUI);
})();
