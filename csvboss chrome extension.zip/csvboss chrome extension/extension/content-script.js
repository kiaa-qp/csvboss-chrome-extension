(function () {
  function getSessionId() {
    try { return window.g_sessionID || document.cookie.match(/sessionid=([^;]+)/)?.[1] || null; }
    catch { return null; }
  }

  async function addFriend(steamId) {
    const sessionId = getSessionId();
    if (!sessionId) throw new Error('No session ID — are you logged in?');
    const res = await fetch('https://steamcommunity.com/actions/AddFriendAjax', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: `sessionID=${encodeURIComponent(sessionId)}&steamid=${encodeURIComponent(steamId)}&accept_invite=0`
    });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { throw new Error(`HTTP ${res.status}`); }
    if (data.failed_invites_result?.length) {
      const code = data.failed_invites_result[0];
      if (code === 8) throw new Error('already friends or request pending');
      if (code === 84) throw new Error('their profile restricts friend invites');
      throw new Error(`rejected by Steam (code ${code})`);
    }
    if (data.success !== 1) throw new Error(`failed (success=${data.success})`);
  }

  async function removeFriend(steamId) {
    const sessionId = getSessionId();
    if (!sessionId) throw new Error('No session ID — are you logged in?');
    const res = await fetch('https://steamcommunity.com/actions/RemoveFriendAjax', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: `sessionid=${encodeURIComponent(sessionId)}&steamid=${encodeURIComponent(steamId)}`
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${text.slice(0, 120)}`);
  }

  async function setNickname(steamId, nickname) {
    const sessionId = getSessionId();
    if (!sessionId) throw new Error('No session ID — are you logged in?');
    const url = `https://steamcommunity.com/profiles/${steamId}/ajaxsetnickname/`;
    async function attempt() {
      return fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
        body: `nickname=${encodeURIComponent(nickname)}&sessionid=${encodeURIComponent(sessionId)}`
      });
    }
    let res = await attempt().catch(() => null);
    if (!res || !res.ok) {
      await sleep(800);
      res = await attempt().catch(() => null);
    }
    if (!res || !res.ok) throw new Error('Request failed');
    return res.text();
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function parseCSV(text) {
    return text.trim().split('\n')
      .map(l => l.trim()).filter(Boolean)
      .map(line => {
        const parts = line.split(',');
        if (parts.length < 2) return null;
        const steamId = parts[0].trim();
        const nickname = parts[1].trim();
        const lang = parts[2] ? parts[2].trim().toLowerCase() : '';
        if (!/^\d{17}$/.test(steamId)) return null;
        return { steamId, nickname, lang };
      }).filter(Boolean);
  }

  function filterByLang(entries) {
    const checked = [...document.querySelectorAll('.csvboss-lang-cb:checked')].map(c => c.value);
    if (!checked.length || checked.includes('all')) return entries;
    return entries.filter(e => checked.includes(e.lang));
  }

  function buildUI() {
    if (document.getElementById('csvboss-panel')) return;

    const toggle = document.createElement('button');
    toggle.id = 'csvboss-toggle';
    toggle.textContent = 'Nickname Manager';
    document.body.appendChild(toggle);

    const panel = document.createElement('div');
    panel.id = 'csvboss-panel';
    panel.innerHTML = `
      <div id="csvboss-header">
        <div id="csvboss-title">
          Nickname Manager <span>csvboss</span>
        </div>
        <button id="csvboss-close">&#x2715;</button>
      </div>
      <div id="csvboss-body">
        <div class="csvboss-section">
          <div class="csvboss-label">Prefix</div>
          <input id="csvboss-prefix" class="csvboss-input" type="text" placeholder="e.g. [TAG] ">
        </div>
        <div class="csvboss-section">
          <div class="csvboss-label">CSV — steamid64,name</div>
          <textarea id="csvboss-csv" class="csvboss-input" placeholder="76561198000000001,Player One&#10;76561198000000002,Player Two"></textarea>
        </div>
        <div class="csvboss-section">
          <div class="csvboss-label">Language Filter</div>
          <div class="csvboss-lang-row">
            <label class="csvboss-lang-chip"><input class="csvboss-lang-cb" type="checkbox" value="all" checked><span>All</span></label>
            <label class="csvboss-lang-chip"><input class="csvboss-lang-cb" type="checkbox" value="ru"><span>🇷🇺 Russian</span></label>
            <label class="csvboss-lang-chip"><input class="csvboss-lang-cb" type="checkbox" value="en"><span>🇬🇧 English</span></label>
            <label class="csvboss-lang-chip"><input class="csvboss-lang-cb" type="checkbox" value="cn"><span>🇨🇳 Chinese</span></label>
          </div>
        </div>
        <div class="csvboss-stats">
          <div class="csvboss-stat"><div class="num" id="stat-total">0</div><div class="lbl">Entries</div></div>
          <div class="csvboss-stat"><div class="num" id="stat-ok">0</div><div class="lbl">Applied</div></div>
          <div class="csvboss-stat"><div class="num" id="stat-err">0</div><div class="lbl">Failed</div></div>
        </div>
        <div id="csvboss-progress"><div id="csvboss-progress-bar"></div></div>
        <div class="csvboss-row">
          <button class="csvboss-btn csvboss-btn-primary" id="btn-apply">Apply Nicknames</button>
          <button class="csvboss-btn csvboss-btn-secondary" id="btn-clear-input">Clear</button>
        </div>
        <div class="csvboss-divider"></div>
        <div class="csvboss-row">
          <button class="csvboss-btn csvboss-btn-danger" id="btn-unnick">Remove All Nicknames</button>
        </div>
        <div id="csvboss-log"></div>
        <div class="csvboss-divider"></div>
        <div class="csvboss-label">Friend Manager</div>
        <div class="csvboss-friend-actions">
          <button class="csvboss-action-item csvboss-action-add" id="btn-add-friends">
            <span class="csvboss-action-icon">&#10003;</span>
            <span>Add from CSV</span>
          </button>
          <button class="csvboss-action-item csvboss-action-unfriend" id="btn-unfriend-csv">
            <span class="csvboss-action-icon">&#10005;</span>
            <span>Unfriend from CSV</span>
          </button>
        </div>
        <div class="csvboss-stats" id="friend-stats" style="display:none">
          <div class="csvboss-stat"><div class="num" id="stat-f-total">0</div><div class="lbl">Queued</div></div>
          <div class="csvboss-stat"><div class="num" id="stat-f-ok">0</div><div class="lbl">Done</div></div>
          <div class="csvboss-stat"><div class="num" id="stat-f-err">0</div><div class="lbl">Failed</div></div>
        </div>
        <div id="csvboss-progress2"><div id="csvboss-progress-bar2"></div></div>
        <div id="csvboss-log2"></div>
      </div>
    `;
    document.body.appendChild(panel);

    let running = false;
    const csvInput = document.getElementById('csvboss-csv');
    const prefixInput = document.getElementById('csvboss-prefix');
    const log = document.getElementById('csvboss-log');
    const progress = document.getElementById('csvboss-progress');
    const progressBar = document.getElementById('csvboss-progress-bar');

    chrome.storage.local.get(['csvboss_csv', 'csvboss_prefix'], (data) => {
      if (data.csvboss_csv) csvInput.value = data.csvboss_csv;
      if (data.csvboss_prefix) prefixInput.value = data.csvboss_prefix;
      updateStats();
    });
    csvInput.addEventListener('input', () => { chrome.storage.local.set({ csvboss_csv: csvInput.value }); updateStats(); });
    prefixInput.addEventListener('input', () => chrome.storage.local.set({ csvboss_prefix: prefixInput.value }));

    function updateStats() {
      document.getElementById('stat-total').textContent = filterByLang(parseCSV(csvInput.value)).length;
    }

    document.querySelectorAll('.csvboss-lang-cb').forEach(cb => {
      cb.addEventListener('change', () => {
        if (cb.value === 'all' && cb.checked) {
          document.querySelectorAll('.csvboss-lang-cb:not([value="all"])').forEach(c => c.checked = false);
        } else if (cb.value !== 'all' && cb.checked) {
          document.querySelector('.csvboss-lang-cb[value="all"]').checked = false;
        }
        updateStats();
      });
    });

    function addLog(msg, type = 'info') {
      log.classList.add('visible');
      const line = document.createElement('div');
      line.className = `log-${type}`;
      line.textContent = msg;
      log.appendChild(line);
      log.scrollTop = log.scrollHeight;
    }
    function clearLog() { log.innerHTML = ''; log.classList.remove('visible'); }

    function lockBtns(lock) {
      document.querySelectorAll('.csvboss-btn, .csvboss-action-item').forEach(b => b.disabled = lock);
    }

    document.getElementById('btn-apply').addEventListener('click', async () => {
      if (running) return;
      clearLog();
      const entries = filterByLang(parseCSV(csvInput.value));
      if (!entries.length) { addLog('No valid entries.', 'err'); return; }
      const prefix = prefixInput.value.trim();
      running = true; lockBtns(true);
      progress.classList.add('visible'); progressBar.style.width = '0%';
      document.getElementById('stat-ok').textContent = '0';
      document.getElementById('stat-err').textContent = '0';
      addLog(`Applying ${entries.length} nicknames...`);
      let ok = 0, err = 0;
      for (let i = 0; i < entries.length; i++) {
        const { steamId, nickname } = entries[i];
        const full = prefix ? `${prefix}${nickname}` : nickname;
        try {
          await setNickname(steamId, full);
          ok++;
          addLog(`+ ${steamId}  ${full}`, 'ok');
        } catch (e) {
          err++;
          addLog(`- ${steamId}  ${e.message}`, 'err');
        }
        document.getElementById('stat-ok').textContent = ok;
        document.getElementById('stat-err').textContent = err;
        progressBar.style.width = `${((i + 1) / entries.length) * 100}%`;
        await sleep(1500);
      }
      addLog(`Finished. ${ok} applied, ${err} failed.`);
      running = false; lockBtns(false);
    });

    document.getElementById('btn-unnick').addEventListener('click', async () => {
      if (running) return;
      if (!confirm('Remove ALL Steam nicknames? This cannot be undone.')) return;
      clearLog();
      running = true; lockBtns(true);
      progress.classList.add('visible'); progressBar.style.width = '0%';
      addLog('Fetching friends list...');
      try {
        const res = await fetch('https://steamcommunity.com/my/friends/', { credentials: 'include' });
        const html = await res.text();
        const matches = [...html.matchAll(/data-steamid="(\d{17})"/g)];
        const steamIds = [...new Set(matches.map(m => m[1]))];
        if (!steamIds.length) { addLog('No friends found or not logged in.', 'err'); running = false; lockBtns(false); return; }
        addLog(`Found ${steamIds.length} users. Clearing nicknames...`);
        document.getElementById('stat-total').textContent = steamIds.length;
        document.getElementById('stat-ok').textContent = '0';
        document.getElementById('stat-err').textContent = '0';
        let ok = 0, err = 0;
        for (let i = 0; i < steamIds.length; i++) {
          try {
            await setNickname(steamIds[i], '');
            ok++;
            addLog(`+ cleared ${steamIds[i]}`, 'ok');
          } catch (e) {
            err++;
            addLog(`- ${steamIds[i]}  ${e.message}`, 'err');
          }
          document.getElementById('stat-ok').textContent = ok;
          document.getElementById('stat-err').textContent = err;
          progressBar.style.width = `${((i + 1) / steamIds.length) * 100}%`;
          await sleep(1500);
        }
        addLog(`Done. ${ok} cleared, ${err} failed.`);
      } catch (e) { addLog(`Error: ${e.message}`, 'err'); }
      running = false; lockBtns(false);
    });

    const progress2 = document.getElementById('csvboss-progress2');
    const progressBar2 = document.getElementById('csvboss-progress-bar2');
    const log2 = document.getElementById('csvboss-log2');
    const friendStats = document.getElementById('friend-stats');

    function addLog2(msg, type = 'info') {
      log2.classList.add('visible');
      const line = document.createElement('div');
      line.className = `log-${type}`;
      line.textContent = msg;
      log2.appendChild(line);
      log2.scrollTop = log2.scrollHeight;
    }
    function clearLog2() { log2.innerHTML = ''; log2.classList.remove('visible'); }

    async function runFriendOp(label, op) {
      if (running) return;
      const entries = filterByLang(parseCSV(csvInput.value));
      if (!entries.length) { addLog2('No valid entries in CSV.', 'err'); return; }
      running = true; lockBtns(true);
      clearLog2();
      friendStats.style.display = 'flex';
      progress2.classList.add('visible'); progressBar2.style.width = '0%';
      document.getElementById('stat-f-total').textContent = entries.length;
      document.getElementById('stat-f-ok').textContent = '0';
      document.getElementById('stat-f-err').textContent = '0';
      addLog2(`${label} ${entries.length} users...`);
      let ok = 0, err = 0;
      for (let i = 0; i < entries.length; i++) {
        const { steamId } = entries[i];
        try {
          await op(steamId);
          ok++;
          addLog2(`+ ${steamId}`, 'ok');
        } catch (e) {
          err++;
          addLog2(`- ${steamId}  ${e.message}`, 'err');
        }
        document.getElementById('stat-f-ok').textContent = ok;
        document.getElementById('stat-f-err').textContent = err;
        progressBar2.style.width = `${((i + 1) / entries.length) * 100}%`;
        await sleep(1500);
      }
      addLog2(`Done. ${ok} succeeded, ${err} failed.`);
      running = false; lockBtns(false);
    }

    document.getElementById('btn-add-friends').addEventListener('click', () => {
      runFriendOp('Sending friend requests to', addFriend);
    });

    document.getElementById('btn-unfriend-csv').addEventListener('click', () => {
      if (!confirm('Unfriend all users in the CSV? This cannot be undone.')) return;
      runFriendOp('Unfriending', removeFriend);
    });

    document.getElementById('btn-clear-input').addEventListener('click', () => {
      csvInput.value = ''; chrome.storage.local.remove('csvboss_csv'); updateStats(); clearLog();
    });

    document.getElementById('csvboss-close').addEventListener('click', () => {
      panel.style.display = 'none'; toggle.style.display = 'block';
    });
    toggle.addEventListener('click', () => {
      panel.style.display = 'block'; toggle.style.display = 'none';
    });

    let dragging = false, dx = 0, dy = 0;
    document.getElementById('csvboss-header').addEventListener('mousedown', e => {
      dragging = true;
      dx = e.clientX - panel.getBoundingClientRect().left;
      dy = e.clientY - panel.getBoundingClientRect().top;
    });
    document.addEventListener('mousemove', e => {
      if (!dragging) return;
      panel.style.right = 'auto';
      panel.style.left = `${e.clientX - dx}px`;
      panel.style.top = `${e.clientY - dy}px`;
    });
    document.addEventListener('mouseup', () => dragging = false);
  }

  if (document.readyState === 'complete') buildUI();
  else window.addEventListener('load', buildUI);
})();
