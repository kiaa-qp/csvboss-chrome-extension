(function () {
  function getSessionId() {
    try { return window.g_sessionID || document.cookie.match(/sessionid=([^;]+)/)?.[1] || null; }
    catch { return null; }
  }

  async function setNickname(steamId, nickname) {
    const sessionId = getSessionId();
    if (!sessionId) throw new Error('No session ID — are you logged in?');
    const url = `https://steamcommunity.com/profiles/${steamId}/ajaxsetnickname/`;
    async function attempt() {
      return fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
        body: `nickname=${encodeURIComponent(nickname)}&sessionid=${encodeURIComponent(sessionId)}`
      });
    }
    let res = await attempt().catch(() => null);
    if (!res || !res.ok) {
      await sleep(800);
      res = await attempt().catch(() => null);
    }
    if (!res || !res.ok) throw new Error('Request failed');
    return res.text();
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function parseCSV(text) {
    return text.trim().split('\n')
      .map(l => l.trim()).filter(Boolean)
      .map(line => {
        const i = line.indexOf(',');
        if (i === -1) return null;
        const steamId = line.slice(0, i).trim();
        const nickname = line.slice(i + 1).trim();
        if (!/^\d{17}$/.test(steamId)) return null;
        return { steamId, nickname };
      }).filter(Boolean);
  }

  function buildUI() {
    if (document.getElementById('csvboss-panel')) return;

    const toggle = document.createElement('button');
    toggle.id = 'csvboss-toggle';
    toggle.textContent = 'Nickname Manager';
    document.body.appendChild(toggle);

    const panel = document.createElement('div');
    panel.id = 'csvboss-panel';
    panel.innerHTML = `
      <div id="csvboss-header">
        <div id="csvboss-title">
          Nickname Manager <span>csvboss</span>
        </div>
        <button id="csvboss-close">&#x2715;</button>
      </div>
      <div id="csvboss-body">
        <div class="csvboss-section">
          <div class="csvboss-label">Prefix</div>
          <input id="csvboss-prefix" class="csvboss-input" type="text" placeholder="e.g. [TAG] ">
        </div>
        <div class="csvboss-section">
          <div class="csvboss-label">CSV — steamid64,name</div>
          <textarea id="csvboss-csv" class="csvboss-input" placeholder="76561198000000001,Player One&#10;76561198000000002,Player Two"></textarea>
        </div>
        <div class="csvboss-stats">
          <div class="csvboss-stat"><div class="num" id="stat-total">0</div><div class="lbl">Entries</div></div>
          <div class="csvboss-stat"><div class="num" id="stat-ok">0</div><div class="lbl">Applied</div></div>
          <div class="csvboss-stat"><div class="num" id="stat-err">0</div><div class="lbl">Failed</div></div>
        </div>
        <div id="csvboss-progress"><div id="csvboss-progress-bar"></div></div>
        <div class="csvboss-row">
          <button class="csvboss-btn csvboss-btn-primary" id="btn-apply">Apply Nicknames</button>
          <button class="csvboss-btn csvboss-btn-secondary" id="btn-clear-input">Clear</button>
        </div>
        <div class="csvboss-divider"></div>
        <div class="csvboss-row">
          <button class="csvboss-btn csvboss-btn-danger" id="btn-unnick">Remove All Nicknames</button>
        </div>
        <div id="csvboss-log"></div>
      </div>
    `;
    document.body.appendChild(panel);

    let running = false;
    const csvInput = document.getElementById('csvboss-csv');
    const prefixInput = document.getElementById('csvboss-prefix');
    const log = document.getElementById('csvboss-log');
    const progress = document.getElementById('csvboss-progress');
    const progressBar = document.getElementById('csvboss-progress-bar');

    chrome.storage.local.get(['csvboss_csv', 'csvboss_prefix'], (data) => {
      if (data.csvboss_csv) csvInput.value = data.csvboss_csv;
      if (data.csvboss_prefix) prefixInput.value = data.csvboss_prefix;
      updateStats();
    });
    csvInput.addEventListener('input', () => { chrome.storage.local.set({ csvboss_csv: csvInput.value }); updateStats(); });
    prefixInput.addEventListener('input', () => chrome.storage.local.set({ csvboss_prefix: prefixInput.value }));

    function updateStats() {
      document.getElementById('stat-total').textContent = parseCSV(csvInput.value).length;
    }

    function addLog(msg, type = 'info') {
      log.classList.add('visible');
      const line = document.createElement('div');
      line.className = `log-${type}`;
      line.textContent = msg;
      log.appendChild(line);
      log.scrollTop = log.scrollHeight;
    }
    function clearLog() { log.innerHTML = ''; log.classList.remove('visible'); }

    function lockBtns(lock) {
      document.querySelectorAll('.csvboss-btn').forEach(b => b.disabled = lock);
    }

    document.getElementById('btn-apply').addEventListener('click', async () => {
      if (running) return;
      clearLog();
      const entries = parseCSV(csvInput.value);
      if (!entries.length) { addLog('No valid entries.', 'err'); return; }
      const prefix = prefixInput.value.trim();
      running = true; lockBtns(true);
      progress.classList.add('visible'); progressBar.style.width = '0%';
      document.getElementById('stat-ok').textContent = '0';
      document.getElementById('stat-err').textContent = '0';
      addLog(`Applying ${entries.length} nicknames...`);
      let ok = 0, err = 0;
      for (let i = 0; i < entries.length; i++) {
        const { steamId, nickname } = entries[i];
        const full = prefix ? `${prefix}${nickname}` : nickname;
        try {
          await setNickname(steamId, full);
          ok++;
          addLog(`+ ${steamId}  ${full}`, 'ok');
        } catch (e) {
          err++;
          addLog(`- ${steamId}  ${e.message}`, 'err');
        }
        document.getElementById('stat-ok').textContent = ok;
        document.getElementById('stat-err').textContent = err;
        progressBar.style.width = `${((i + 1) / entries.length) * 100}%`;
        await sleep(1500);
      }
      addLog(`Finished. ${ok} applied, ${err} failed.`);
      running = false; lockBtns(false);
    });

    document.getElementById('btn-unnick').addEventListener('click', async () => {
      if (running) return;
      if (!confirm('Remove ALL Steam nicknames? This cannot be undone.')) return;
      clearLog();
      running = true; lockBtns(true);
      progress.classList.add('visible'); progressBar.style.width = '0%';
      addLog('Fetching friends list...');
      try {
        const res = await fetch('https://steamcommunity.com/my/friends/', { credentials: 'include' });
        const html = await res.text();
        const matches = [...html.matchAll(/data-steamid="(\d{17})"/g)];
        const steamIds = [...new Set(matches.map(m => m[1]))];
        if (!steamIds.length) { addLog('No friends found or not logged in.', 'err'); running = false; lockBtns(false); return; }
        addLog(`Found ${steamIds.length} users. Clearing nicknames...`);
        document.getElementById('stat-total').textContent = steamIds.length;
        document.getElementById('stat-ok').textContent = '0';
        document.getElementById('stat-err').textContent = '0';
        let ok = 0, err = 0;
        for (let i = 0; i < steamIds.length; i++) {
          try {
            await setNickname(steamIds[i], '');
            ok++;
            addLog(`+ cleared ${steamIds[i]}`, 'ok');
          } catch (e) {
            err++;
            addLog(`- ${steamIds[i]}  ${e.message}`, 'err');
          }
          document.getElementById('stat-ok').textContent = ok;
          document.getElementById('stat-err').textContent = err;
          progressBar.style.width = `${((i + 1) / steamIds.length) * 100}%`;
          await sleep(1500);
        }
        addLog(`Done. ${ok} cleared, ${err} failed.`);
      } catch (e) { addLog(`Error: ${e.message}`, 'err'); }
      running = false; lockBtns(false);
    });

    document.getElementById('btn-clear-input').addEventListener('click', () => {
      csvInput.value = ''; chrome.storage.local.remove('csvboss_csv'); updateStats(); clearLog();
    });

    document.getElementById('csvboss-close').addEventListener('click', () => {
      panel.style.display = 'none'; toggle.style.display = 'block';
    });
    toggle.addEventListener('click', () => {
      panel.style.display = 'block'; toggle.style.display = 'none';
    });

    let dragging = false, dx = 0, dy = 0;
    document.getElementById('csvboss-header').addEventListener('mousedown', e => {
      dragging = true;
      dx = e.clientX - panel.getBoundingClientRect().left;
      dy = e.clientY - panel.getBoundingClientRect().top;
    });
    document.addEventListener('mousemove', e => {
      if (!dragging) return;
      panel.style.right = 'auto';
      panel.style.left = `${e.clientX - dx}px`;
      panel.style.top = `${e.clientY - dy}px`;
    });
    document.addEventListener('mouseup', () => dragging = false);
  }

  if (document.readyState === 'complete') buildUI();
  else window.addEventListener('load', buildUI);
})();
